#This file will be used to load our SQL database into python, handle null values and catagorize data numerically and catagorical data.

import pyodbc
import pandas as pd

#this will catagorize text columns from numerical ones, satisfying part of task 6 from our sprint backlog
TEXT_COLUMNS = ["Name", "Club", "Position", "Nationality", "Jersey_Number"]

#this is the pipeline and will satisfy system requirements 020 and 030
#it also satisfies Task 5 (Add SQL database to python using a pipeline) from our sprint backlog
def load_players():
    connection = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        r"SERVER=SPENCER\SQLSERVER;"
        "DATABASE=FootballAnalytics;"
        "Trusted_Connection=yes;"
        "TrustServerCertificate=yes;"
    )
    df = pd.read_sql("SELECT * FROM dbo.Players", connection)
    connection.close()
    return df

# 2. (REQ-SYS-050) pandas: "manipulate numerical data"
def prepare_numeric(df):
    df = df.copy()

    #nulls and blanks will become real missing values
    df = df.replace(["", "NULL"], pd.NA)
    #everything that isn't a text column is a stat, so turn those into numbers
    numeric_columns = [c for c in df.columns if c not in TEXT_COLUMNS]
    for col in numeric_columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    return df, numeric_columns

#other files call this to get the clean data so we don't have to create the same pipeline for each file
def get_data():
    return prepare_numeric(load_players())

if __name__ == "__main__":
    df, numeric_columns = get_data()
    text_df = df[TEXT_COLUMNS]
    numeric_df = df[numeric_columns]
    print("Total players:", len(df))
    print("Text columns:", len(TEXT_COLUMNS), "| Numeric columns:", len(numeric_columns))
    print(df.head(10))