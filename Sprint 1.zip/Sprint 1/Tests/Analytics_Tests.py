#quick tests for the analytics files, uses a tiny fake table so sql server doesn't need to be on
#run with: python Tests\Analytics_Test.py
 
import os
import sys
import unittest
import numpy as np
import pandas as pd
 
#adds the Sprint 1 folder so python can find the Analytics folder
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from Analytics.Top_Shooters import top_shooters
from Analytics.Highest_scorers_by_career import top_scorers
from Analytics.Hypothesis_Test import run_test
from Analytics.Team_Shooting_Accuracy_Visual import team_accuracy
 
 
def fake_table():
    return pd.DataFrame({
        "Name": ["A", "B", "C", "D"],
        "Club": ["X", "X", "Y", "Y"],
        "Position": ["Forward"] * 4,
        "Appearances": [100, 50, 10, 200],
        "Goals": [50, 10, 9, 20],
        "Shots": [100, 40, 19, 200],
        "Shots_on_target": [50, 10, 15, 60],
        "Shooting_accuracy": [0.50, 0.25, 0.75, 0.30],
    })
 
 
class TestAnalytics(unittest.TestCase):
 
    def test_top_shooters_best_first_and_skips_under_30_shots(self):
        result = top_shooters(fake_table())
        self.assertEqual(list(result["Name"]), ["A", "D", "B"])  #C has 0.75 but only 20 shots
 
    def test_top_scorers_goals_per_game_and_skips_under_20_games(self):
        result = top_scorers(fake_table())
        self.assertEqual(list(result["Name"]), ["A", "B", "D"])  #C only has 10 games
        self.assertEqual(result.iloc[0]["Goals_Per_Appearance"], 0.5)
 
    def test_hypothesis_finds_a_real_relationship(self):
        df = pd.DataFrame({
            "Appearances": np.arange(1, 61),
            "Shots": [50] * 60,
            "Shooting_accuracy": np.linspace(0.1, 0.6, 60),
        })
        players, r, p_value = run_test(df, shuffles=500)
        self.assertEqual(players, 60)
        self.assertAlmostEqual(r, 1.0, places=3)
        self.assertLess(p_value, 0.05)
 
    def test_hypothesis_finds_nothing_in_random_data(self):
        rng = np.random.default_rng(1)
        df = pd.DataFrame({
            "Appearances": rng.integers(1, 300, 80),
            "Shots": [50] * 80,
            "Shooting_accuracy": rng.random(80),
        })
        players, r, p_value = run_test(df, shuffles=500)
        self.assertGreater(p_value, 0.05)
 
    def test_team_accuracy_uses_total_shots_and_sorts_lowest_first(self):
        teams = team_accuracy(fake_table())
        self.assertEqual(teams.loc["X", "Team_Shooting_Accuracy"], round(60 / 140, 3))
        self.assertEqual(teams.loc["Y", "Team_Shooting_Accuracy"], round(75 / 219, 3))
        self.assertEqual(list(teams.index), ["Y", "X"])
 
 
if __name__ == "__main__":
    unittest.main(verbosity=2)