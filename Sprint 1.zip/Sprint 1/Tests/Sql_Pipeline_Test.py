#this is a simple for SQL_Pipeline.py, to prevent any odd SQL pipeline errors I'll make a fake table.
#run with: python -m unittest test_sql_pipeline -v
 
import unittest
from unittest.mock import patch
 
import pandas as pd
import sys 
import os
#code below lets python see the entire sprint 1 folder so we it can access the pipeline
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from Pipeline import SQL_Pipeline
from Pipeline.SQL_Pipeline import prepare_numeric, get_data
 
 
def fake_table():
    return pd.DataFrame({
        "Name": ["A", "B"],
        "Club": ["X", "Y"],
        "Position": ["Forward", "Defender"],
        "Nationality": ["England", "Spain"],
        "Jersey_Number": ["9", "4"],
        "Goals": ["10", ""],
        "Assists": ["3", "NULL"],
    })
 
 
class TestPipeline(unittest.TestCase):
 
    def test_blanks_and_null_become_missing(self):
        clean, numeric = prepare_numeric(fake_table())
        self.assertTrue(pd.isna(clean.loc[1, "Goals"]))
        self.assertTrue(pd.isna(clean.loc[1, "Assists"]))
 
    def test_stats_become_numbers(self):
        clean, numeric = prepare_numeric(fake_table())
        self.assertEqual(numeric, ["Goals", "Assists"])
        self.assertTrue(pd.api.types.is_numeric_dtype(clean["Goals"]))
 
    def test_text_columns_stay_text(self):
        clean, numeric = prepare_numeric(fake_table())
        self.assertEqual(clean.loc[0, "Name"], "A")
        self.assertNotIn("Jersey_Number", numeric)
 
    def test_get_data_gives_back_clean_table(self):
        with patch.object(SQL_Pipeline, "load_players", return_value=fake_table()):
            df, numeric = get_data()
        self.assertEqual(len(df), 2)
        self.assertEqual(df.loc[0, "Goals"], 10)
 
 
if __name__ == "__main__":
    unittest.main(verbosity=2)