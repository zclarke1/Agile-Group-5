#imports
import numpy as np

#question: do players who have played more games shoot more accurately?
#H0 (null): there is no relationship between games played and shooting accuracy
#H1 (alternative): there is a relationship
def run_test(df, shuffles=10000):
    #only players with at least 30 shots so a lucky player with 2 shots doesn't mess it up
    players = df.dropna(subset=["Appearances", "Shots", "Shooting_accuracy"])
    players = players[players["Shots"] >= 30]

    games = players["Appearances"].to_numpy(dtype=float)
    accuracy = players["Shooting_accuracy"].to_numpy(dtype=float)

    #r = how strongly games played and accuracy move together (-1 to 1)
    r = np.corrcoef(games, accuracy)[0, 1]

    #p-value: shuffle the games column so any real link is destroyed,
    #then count how often a shuffled r is as strong as ours just by luck
    rng = np.random.default_rng(72030)
    count = 0
    for i in range(shuffles):
        shuffled_r = np.corrcoef(rng.permutation(games), accuracy)[0, 1]
        if abs(shuffled_r) >= abs(r):
            count = count + 1
    p_value = (count + 1) / (shuffles + 1)

    return len(players), r, p_value

#this part only runs when the file is run directly
if __name__ == "__main__":
    import os
    import sys
    #get path for sql pipeline
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    from Pipeline.SQL_Pipeline import get_data

    df, numeric_columns = get_data()
    players, r, p_value = run_test(df)

    print("Players compared:", players)
    print("r =", round(r, 3))
    print("p-value =", round(p_value, 4))

    if p_value < 0.05:
        print("Reject H0: there is a relationship between games played and accuracy")
    else:
        print("Fail to reject H0: no evidence that more games means better accuracy")
print ("Since the p-value (0.94) is greater than 0.05 and r is almost 0 (0.006), we fail to reject H0: there is no evidence that players with more experience shoot more accurately")