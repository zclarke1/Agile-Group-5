#imports
import numpy as np

#team shooting accuracy = total shots on target / total shots for the whole club
#(this way a player with 5 shots doesn't count the same as one with 500)
def team_accuracy(df):
    teams = df.dropna(subset=["Club", "Shots", "Shots_on_target"]).groupby("Club")[["Shots", "Shots_on_target"]].sum()
    teams["Team_Shooting_Accuracy"] = np.round(teams["Shots_on_target"] / teams["Shots"], 3)
    return teams.sort_values("Team_Shooting_Accuracy")

#this part only runs when the file is run directly
if __name__ == "__main__":
    import os
    import sys
    import matplotlib.pyplot as plt
    #get path for sql pipeline
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    from Pipeline.SQL_Pipeline import get_data

    df, numeric_columns = get_data()
    teams = team_accuracy(df)
    teams.to_csv("team_shooting_accuracy.csv")

    #bar graph, best team ends up on top
    names = [club.replace("-", " ") for club in teams.index]
    values = teams["Team_Shooting_Accuracy"] * 100

    plt.figure(figsize=(8, 6.5))
    bars = plt.barh(names, values)
    for bar, value in zip(bars, values):
        plt.text(value + 0.4, bar.get_y() + bar.get_height() / 2, f"{value:.1f}%", va="center")
    plt.title("Team shooting accuracy (shots on target / total shots)")
    plt.xlabel("Shooting accuracy (%)")
    plt.tight_layout()
    plt.savefig("team_shooting_accuracy.png", dpi=160)
    plt.show()