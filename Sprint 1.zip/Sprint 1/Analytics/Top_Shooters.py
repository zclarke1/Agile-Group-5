#imports
import numpy as np
import os
import sys
#get path for sql pipeline
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from Pipeline.SQL_Pipeline import get_data
#top 10 shooting accuracy, minimum 20 shots so players with a small amount of shots but high accuracy don't win
def top_shooters(df):
    shooters = df.dropna(subset=["Shots", "Shooting_accuracy"])
    shooters = shooters[shooters["Shots"] >= 20]

    accuracy = shooters["Shooting_accuracy"].to_numpy(dtype=float)
    order = np.argsort(-accuracy, kind="stable")[:10]

    return shooters.iloc[order][["Name", "Club", "Position", "Shots", "Shots_on_target", "Shooting_accuracy"]]

if __name__ == "__main__":
    df, numeric_columns = get_data()
    print("Total players:", len(df)) #test to make sure pipeline works
    result = top_shooters(df)
    result.to_csv("top_10_shooting_accuracy.csv", index=False)
    print(result.to_string(index=False))