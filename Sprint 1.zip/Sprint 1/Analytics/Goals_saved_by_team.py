import os
import sys
import numpy as np
#get path for sql pipeline
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from Pipeline.SQL_Pipeline import get_data
df, numeric_columns = get_data()
def clean_games(df):
    cleansheetsbyteam = df.dropna(subset=["Club", "Clean sheets"]).groupby("Club")[["Clean sheets"]].sum()
    accuracy = cleansheetsbyteam["Clean sheet total"].to_numpy(dtype=float)
    order = np.argsort(-accuracy, kind="stable")[:10]
    return cleansheetsbyteam.iloc[order][["Club", "Clean sheets"]]