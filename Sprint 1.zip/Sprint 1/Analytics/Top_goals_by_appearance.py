#imports
import numpy as np

#best scorers per game = goals / appearances, minimum 20 appearances so players with a small amount of games but a high goal rate don't win
def top_scorers(df):
    players = df.dropna(subset=["Goals", "Appearances"])
    players = players[players["Appearances"] >= 20].copy()

    goals = players["Goals"].to_numpy(dtype=float)
    games = players["Appearances"].to_numpy(dtype=float)
    players["Goals_Per_Appearance"] = np.round(goals / games, 3)

    order = np.argsort(-players["Goals_Per_Appearance"].to_numpy(), kind="stable")[:10]
    return players.iloc[order][["Name", "Club", "Position", "Appearances", "Goals", "Goals_Per_Appearance"]]

#this part only runs when the file is run directly
if __name__ == "__main__":
    import os
    import sys
    #get path for sql pipeline
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    from Pipeline.SQL_Pipeline import get_data

    df, numeric_columns = get_data()
    result = top_scorers(df)
    result.to_csv("top_10_scorers_per_game.csv", index=False)
    print(result.to_string(index=False))